function Start ()
    {
        Screen.showCursor = false;
    }