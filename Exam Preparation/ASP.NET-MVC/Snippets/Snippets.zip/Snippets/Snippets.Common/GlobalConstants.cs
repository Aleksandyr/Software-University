﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snippets.Common
{
    public class GlobalConstants
    {
        public const int HomePageNumber = 5;
    }
}
