﻿namespace Snippets.Common.Mappings
{
    public interface IMapTo<T>
    {
    }
}
