﻿namespace Snippets.Common.Mappings
{
    public interface IMapFrom<T>
    {
    }
}
