﻿namespace BangaloreUniversityLearningSystem
{
    using Core;

    public class Program
    {
        public static void Main()
        {
            var bangaloreUniversityEngine = new BangaloreUniversityEngine();

            bangaloreUniversityEngine.Run();
        }
    }
}