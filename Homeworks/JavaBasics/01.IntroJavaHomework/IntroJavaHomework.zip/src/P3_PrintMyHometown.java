
public class P3_PrintMyHometown {
	public static void main(String[] args) {
		System.out.println("Blagoebgrad");
	}
}
