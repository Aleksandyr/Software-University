import java.util.Scanner;


public class P6_SumTwoNumbers {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int firstNumber = in.nextInt();
		int secondNumber = in.nextInt();
		
		System.out.println(firstNumber + secondNumber);
	}
}
