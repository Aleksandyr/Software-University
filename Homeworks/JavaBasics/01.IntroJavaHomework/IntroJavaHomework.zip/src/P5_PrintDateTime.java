import java.util.Date;


public class P5_PrintDateTime {
	public static void main(String[] args) {
		System.out.println(new Date());
	}
}	
