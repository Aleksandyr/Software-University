﻿using System;

namespace TheaterSystem.Exceptions
{
    internal class TheatreNotFoundException : Exception
    {
        public TheatreNotFoundException(string msg)
            : base(msg)
        {


        }
    }
}