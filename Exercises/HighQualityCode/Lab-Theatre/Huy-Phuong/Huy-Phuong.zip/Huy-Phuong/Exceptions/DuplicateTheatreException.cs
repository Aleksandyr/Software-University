﻿namespace TheaterSystem.Exceptions
{
    using System;

    class DuplicateTheatreException : Exception
    {
        public DuplicateTheatreException(string msg)
            : base(msg)
        {
        }
    }
}
